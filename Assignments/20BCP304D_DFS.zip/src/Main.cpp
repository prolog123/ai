#include "TwoJug/TwoJug.h"

#include <iostream>

int main()
{
	std::cout << "Jay Nakum\t20BCP304D" << std::endl;
	TwoJugs::main();
}