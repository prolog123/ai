#pragma once

namespace TwoJugs
{
	void main();
}